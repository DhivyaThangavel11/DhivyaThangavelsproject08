package org.proposalinbox.com;

import org.openqa.selenium.WebElement;

public class AdddressInfo extends CustomerInformation {

	public static void communicationAdress() {

		WebElement flatno = findElementbyId("objAddressAddress1");
		send_keys(flatno, "2/4B");

		WebElement buildingname = findElementbyId("objAddressAddress2");
		send_keys(buildingname, "Rajaveer Complex");

		WebElement streetname = findElementbyId("objAddressAddress3");
		send_keys(streetname, "Tatabad street");

		WebElement statename = findElementbyXpath("//span[@aria-owns='objAddressddlState_listbox']");
		send_keys(statename, "TAMIL NADU");

		WebElement districtname = findElementbyXpath("//span[@aria-owns='objAddressddlDistrict_listbox']");
		send_keys(districtname, "COIMBATORE");

		WebElement townname = findElementbyXpath("//span[@aria-owns='objAddressddlCity_listbox']");
		send_keys(townname, "COIMBATORE SOUTH");

		WebElement pincode = findElementbyXpath("//span[@aria-owns='objAddressddlArea_listbox']");
		send_keys(pincode, "641110");
		

		WebElement mobileno = findElementbyId("txtMobileNumber");
		send_keys(mobileno, "7539973781");

		WebElement emailid = findElementbyId("txtEmailID");
		send_keys(emailid, "dhivya.t@kgisl.com");

	}
	
	
	public static void permananentAddressSame() {
		
		WebElement sameaddresscheckbox= findElementbyId("chkIsPermanentAddrSame");
		clickbutton(sameaddresscheckbox);
		
		
	}
public static void validateCustomer() {
		
		WebElement validatecustomer= findElementbyId("btnValidateHWClient");
		clickbutton(validatecustomer);
		
		
	}
	
	

}
