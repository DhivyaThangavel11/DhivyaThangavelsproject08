package org.proposalinbox.com;

import org.Login.page.BSMLoginPage;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class SearchProposal extends BSMLoginPage {
	
	
	
	@Test
	public static void bsmLogin() {
		WebElement usernameclk=	findElementbyId("txtUserName");
		clickbutton(usernameclk);
		WebElement username=	findElementbyId("txtUserName");
		send_keys(username, "70037774");
		WebElement passwrdclk=	findElementbyId("txtPassword");
		clickbutton(passwrdclk);
		WebElement Password=	findElementbyId("txtPassword");
		send_keys(Password, "Pass@123");
		WebElement captchaclk=	findElementbyId("CaptchaInputText");
		clickbutton(captchaclk);
		WebElement captcha=	findElementbyId("CaptchaInputText");
		send_keys(captcha, "TGHB");
		WebElement loginbtn=	findElementbyId("btnLogin");
		clickbutton(loginbtn);
		
			
		}
	
	
	@Test 
	
	public static void searchProposal() throws InterruptedException {
		
		waitThread(5000) ;
		WebElement searchproposalsfld=	findElementbyId("txtSearchProposal");
		clickbutton(searchproposalsfld);
		WebElement searchproposals=	findElementbyId("txtSearchProposal");
		send_keys(searchproposals, "P021125100070");
		waitThread(2000) ;
		
		WebElement gobtn=	findElementbyId("imgSearchProposal");
		
		clickbutton(gobtn);
		waitThread(3000);
		
		WebElement clickproposal=findElementbyXpath("/html/body/div[6]/div[1]/div/form/div/div[2]/fieldset/div[2]/div/table/tbody/tr/td[1]/a");
		clickbutton(clickproposal);
		waitThread(2000);
        WebElement edtbtn=	findElementbyId("btnEdit");
		
		clickbutton(edtbtn);
		
		
		
	}
	
	
	

}
