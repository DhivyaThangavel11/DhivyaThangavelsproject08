package org.proposalinbox.com;

public class OptionalCoverSection extends NomineeDetailsSection{

}
