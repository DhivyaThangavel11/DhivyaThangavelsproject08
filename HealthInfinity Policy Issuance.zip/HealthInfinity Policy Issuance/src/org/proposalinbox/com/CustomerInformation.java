package org.proposalinbox.com;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class CustomerInformation extends SearchProposal {
	
	
	@Test
	
	public static void customerInfo() throws InterruptedException {
		
		WebElement dob = findElementbyId("DPDateOfBirth");
		send_keys(dob, "11-08-1997");
		System.out.println("DOB completed");
				
		WebElement saluattion = findElementbyXpath("//span[@aria-owns='ddlSalutation_listbox']");
		send_keys(saluattion, "Mrs.");
		WebElement maritalstatus = findElementbyXpath("//span[@aria-owns='ddlMaritalStatus_listbox']");
		send_keys(maritalstatus, "Married");
		WebElement occupation = findElementbyXpath("//span[@aria-owns='ddlOccupation_listbox']");
		send_keys(occupation, "Businessman/Industrialist Medium Scale");
		WebElement annulaincome = findElementbyId("txtAnnualIncome");
		send_keys(annulaincome, "60000");

		
		
		
		
		
		
		
	}

}
