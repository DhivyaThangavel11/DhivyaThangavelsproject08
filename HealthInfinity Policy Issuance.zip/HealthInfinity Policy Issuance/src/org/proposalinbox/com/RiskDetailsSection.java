package org.proposalinbox.com;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RiskDetailsSection extends AdddressInfo {
	
	
	@Test

	public static void riskDetails() throws InterruptedException {
		WebElement tenure = findElementbyXpath("//span[@aria-owns='ddlPolicyTenure_listbox']");
		send_keys(tenure, "1 Year");

		WebElement coverType = findElementbyXpath("//span[@aria-owns='ddlCoverType_listbox']");
		send_keys(coverType, "Individual");

		WebElement sumInsured = findElementbyXpath("//span[@aria-owns='ddlRiskSumInsured_listbox']");
		send_keys(sumInsured, "1000000");

		WebElement noOfpersons1 = findElementbyXpath("//span[@aria-owns='ddlRiskNoOfPersonsToBeCovered_listbox']");
		System.out.println("no of persons completed1");
		clickbutton(noOfpersons1);
		send_keys(noOfpersons1, "3");
		System.out.println("no of persons completed");
		clickbutton(noOfpersons1);

	}
	
	@Test

	public static void selfAddInsured() throws InterruptedException {

		WebElement addinsuredbtn = findElementbyId("btnAddNewInsured");
		clickbutton(addinsuredbtn);

		waitThread(6000);
		System.out.println("height");

		WebElement selfheight = findElementbyId("txtHeight");
		send_keys(selfheight, "144");

		WebElement selfweight = findElementbyId("txtWeight");
		send_keys(selfweight, "44");

		WebElement selfabha = findElementbyXpath("//span[@aria-owns='ddlAbhaAccount_listbox']");
		send_keys(selfabha, "No");

		WebElement selfPED = findElementbyXpath("//span[@aria-owns='chkbPreExistingIllness_listbox']");
		clickbutton(selfPED);
		waitThread(3000);
		send_keys(selfPED, "Yes");
		// waitThread(3000);
		clickbutton(selfPED);

		WebElement adddisease = findElementbyId("btnAddDisease");
		clickbutton(adddisease);
		waitThread(5000);
		System.out.println("add disease");
		WebElement diseasename = findElementbyId("ddlNameOfDisease12");
		send_keys(diseasename, "Anaemia");

		WebElement sufferfrom = findElementbyId("txtPEDSufferFrom");
		send_keys(sufferfrom, "12/2019");

		WebElement exactdiagnosis = findElementbyId("txtExactDiagnosis");
		send_keys(exactdiagnosis, "Anaemia");

		WebElement treatmenttaken = findElementbyId("txtTreatmentTaken");
		send_keys(treatmenttaken, "Yes");

		WebElement diseaseupdatebtn = findElementbyXpath("/html/body/div[87]/div[2]/center/input[1]");
		clickbutton(diseaseupdatebtn);
		waitThread(5000);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[69]/div[2]/center/input[1]")));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scroll(0,450)", "");
		WebElement updatebtn = findElementbyXpath("/html/body/div[69]/div[2]/center/input[1]");

		clickbutton(updatebtn);

	}
	
	@Test

	public static void secondAddInsured() throws InterruptedException {

		WebElement expandrissection = findElementbyId("divRiskDetails");
		clickbutton(expandrissection);

		WebElement addinsuredbtn = findElementbyId("btnAddNewInsured");
		clickbutton(addinsuredbtn);

		waitThread(3000);

		WebElement spouserelationship = findElementbyXpath(
				"//span[@aria-owns='ddlPartialRelationshipWithProposer_listbox']");
		send_keys(spouserelationship, "Spouse");
		
		waitThread(3000);

		WebElement spousesalutation = findElementbyXpath("//span[@aria-owns='ddlInsuredSalutation_listbox']");
		send_keys(spousesalutation, "Mr.");

		WebElement spousefirstname = findElementbyId("txtInsuredFirstName");
		send_keys(spousefirstname, "Elango");

		WebElement spouselastname = findElementbyId("txtInsuredLastName");
		send_keys(spouselastname, "P");

		WebElement spousegender = findElementbyXpath("//span[@aria-owns='ddlInsuredGender_listbox']");
		send_keys(spousegender, "Male");

		WebElement spousemaritalstatus = findElementbyXpath("//span[@aria-owns='ddlMaritalStatusInsured_listbox']");
		send_keys(spousemaritalstatus, "Married");

		WebElement spousedob = findElementbyId("ddlInsuredDateOfBirth");
		send_keys(spousedob, "30-08-1996");

		waitThread(5000);

		WebElement spouseheight = findElementbyId("txtHeight");
		send_keys(spouseheight, "144");

		WebElement spouseweight = findElementbyId("txtWeight");
		send_keys(spouseweight, "44");

		WebElement spouseabha = findElementbyXpath("//span[@aria-owns='ddlAbhaAccount_listbox']");
		send_keys(spouseabha, "No");

		WebElement spousePED = findElementbyXpath("//span[@aria-owns='chkbPreExistingIllness_listbox']");
		clickbutton(spousePED);
		waitThread(3000);
		send_keys(spousePED, "No");
		// waitThread(3000);
		clickbutton(spousePED);

		waitThread(3000);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[69]/div[2]/center/input[1]")));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scroll(0,450)", "");
		WebElement updatebtn = findElementbyXpath("/html/body/div[69]/div[2]/center/input[1]");

		clickbutton(updatebtn);

	}

	 @Test
	public static void thirdAddInsured() throws InterruptedException {

		WebElement addinsuredbtn = findElementbyId("btnAddNewInsured");
		clickbutton(addinsuredbtn);

		waitThread(3000);

		WebElement child1relationship = findElementbyXpath(
				"//span[@aria-owns='ddlPartialRelationshipWithProposer_listbox']");
		send_keys(child1relationship, "Son");

		WebElement child1salutation = findElementbyXpath("//span[@aria-owns='ddlInsuredSalutation_listbox']");
		send_keys(child1salutation, "Mr.");

		WebElement child1firstname = findElementbyId("txtInsuredFirstName");
		send_keys(child1firstname, "Avil");

		WebElement child1lastname = findElementbyId("txtInsuredLastName");
		send_keys(child1lastname, "elango");

		WebElement child1gender = findElementbyXpath("//span[@aria-owns='ddlInsuredGender_listbox']");
		send_keys(child1gender, "Male");

		WebElement child1maritalstatus = findElementbyXpath("//span[@aria-owns='ddlMaritalStatusInsured_listbox']");
		send_keys(child1maritalstatus, "Single");

		WebElement child1dob = findElementbyId("ddlInsuredDateOfBirth");
		send_keys(child1dob, "30-08-2019");

		waitThread(5000);

		WebElement child1height = findElementbyId("txtHeight");
		send_keys(child1height, "144");

		WebElement child1weight = findElementbyId("txtWeight");
		send_keys(child1weight, "44");

		WebElement child1abha = findElementbyXpath("//span[@aria-owns='ddlAbhaAccount_listbox']");
		send_keys(child1abha, "No");

		WebElement child1PED = findElementbyXpath("//span[@aria-owns='chkbPreExistingIllness_listbox']");
		clickbutton(child1PED);
		waitThread(3000);
		send_keys(child1PED, "No");
		// waitThread(3000);
		clickbutton(child1PED);

		waitThread(3000);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[69]/div[2]/center/input[1]")));

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("window.scroll(0,450)", "");
		WebElement updatebtn = findElementbyXpath("/html/body/div[69]/div[2]/center/input[1]");

		clickbutton(updatebtn);

	}

}
