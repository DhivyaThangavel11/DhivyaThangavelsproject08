package org.proposalinbox.com;

import org.openqa.selenium.WebElement;

public class NomineeDetailsSection extends RiskDetailsSection {
	
	public static void nominee() throws InterruptedException{
		
		waitThread(4000);
		System.out.println("nominee");
		waitThread(10000);
		//WebElement nomineesalutaion = findElementbyXpath("/html/body/div[6]/div[1]/div/form/div[1]/fieldset/ul/li[5]/div/div/div[1]/div[1]/div/span/span/span[1]");
		//send_keys(nomineesalutaion, "Mr.");
		
		WebElement nomineefirstname = findElementbyId("txtNomineeFirstName");
		send_keys(nomineefirstname, "Kavin");
		
		WebElement nomineesecondname = findElementbyId("txtNomineeLastName");
		send_keys(nomineesecondname, "M");
		
		WebElement nomineerelationship = findElementbyXpath("/html/body/div[6]/div[1]/div/form/div[1]/fieldset/ul/li[5]/div/div/div[2]/div[2]/span/span/span[1]");
		send_keys(nomineerelationship, "Brother");
		
		WebElement nomineedob = findElementbyId("ddlNomineeDateOfBirth");
		send_keys(nomineedob, "Brother");
		
		

	}
	
	
	

}
