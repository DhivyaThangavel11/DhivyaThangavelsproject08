package org.baseclass;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class RPASBaseClass {

	public static WebDriver driver;
	public static  WebElement element;
	public	static Select s;
	public	static Actions ac;
	
	@Test

	public static void setPropertyMethod(String browsername) {

		System.out.println(browsername); 
		System.out.println("setmethod running");

		switch (browsername) {
		case ("chrome"):

			driver = new ChromeDriver();
			break;

		case ("firefox"):
			System.out.println("test1");
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\dhivya.t\\Desktop\\Selenium\\geckodriver.exe");

			driver = new FirefoxDriver();
			System.out.println("Came inside edge");
			break;

		default:
			System.setProperty("webdriver.edge.driver", "C:\\Users\\dhivya.t\\Desktop\\Selenium\\msedgedriver.exe");
			driver = new EdgeDriver();
			break;
		}
	}
	
	public static void geturl(String url) {
		System.out.println("into url");
		driver.get(url);
	}
	
	public static void maxi_the_window() {

		driver.manage().window().maximize();
	}
	public static WebElement findElementbyId(String id) {
		try {
		WebElement element = driver.findElement(By.id(id));
		return element;
		}catch(Exception e) {
			System.out.println("Error: " + e);
		}
		return element;

	}
	public static void findByname(String name) {
		
	}
	
	public static WebElement findElementbyclassname(String classname) {
		try {
			WebElement element = driver.findElement(By.name(classname));
			return element;
			}catch(Exception e) {
				System.out.println("Error: " + e);
			}
			return element;
	}
	
	
	public static WebElement findElementbyXpath(String xpath) {
		try {
		WebElement element = driver.findElement(By.xpath(xpath));
		return element;
		}
		catch(Exception e) {
			System.out.println("Error: " + e);
		}
		return element;
	}
	public static void findBycss(String css) {
		driver.findElement(By.cssSelector(css));
	}
	
	public static WebElement findElementbyLinktext(String linktext) {
		try {
			
		WebElement element = driver.findElement(By.linkText(linktext));
		} catch(Exception e) {
			System.out.println("Error: " + e);
		}
		return element;
		
	}
	
	public static void findBypartialtext(String partialtext) {
		driver.findElement(By.partialLinkText(partialtext));
	}
	
	public static void enabled(WebElement element) {
		element.isEnabled();
		
	}
	public static void disabled(WebElement element) {
		element.isDisplayed();
		
	}
	
	public static void clickbutton(WebElement element) {
		element.click();
	}
	
	public static void selected(WebElement element) {
		element.isSelected();
		
	}
	public static void send_keys(WebElement element, String valueofkeys) {
		element.sendKeys(valueofkeys);

	}
	
	public static void close_Window() {
		driver.close();
	}
	
	public static void waitThread(long wait) throws InterruptedException {
		Thread.sleep(wait);
	}
	
	public static void dropDownoptions(WebElement element) {
		s = new Select(element);

	}
	public static void selectByvisibletext(String text) {
		s.selectByVisibleText(text);
	}
	public static void explicitWait(Duration secs) {
		WebDriverWait wait = new WebDriverWait(driver, secs);
		wait.until(ExpectedConditions.elementToBeClickable(element));

	}
	
	public static Actions actionEvent(WebDriver driver) {

		ac = new Actions(driver);
		return ac;

	}
	

	
	
	public static void waitForVisibilityOfElement(WebDriver driver, WebElement updatebtn) {		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.visibilityOfElementLocated((By) updatebtn));
	}
}
