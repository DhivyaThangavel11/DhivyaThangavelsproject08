package org.finalexecution.com;

import org.Login.page.BSMLoginPage;
import org.proposalinbox.com.AdddressInfo;
import org.proposalinbox.com.CustomerInformation;
import org.proposalinbox.com.NomineeDetailsSection;
import org.proposalinbox.com.OptionalCoverSection;
import org.proposalinbox.com.RiskDetailsSection;
import org.proposalinbox.com.SearchProposal;

public class FinalExecution extends NomineeDetailsSection {

	public static void main(String[] args) throws InterruptedException {
		
		
		
		setPropertyMethod("chrome");
		
		geturl("https://szuat.reliancegeneral.co.in:100/Login/RPASLogin");
        maxi_the_window();
		bsmLogin();
		searchProposal();
		customerInfo();
		communicationAdress();
		permananentAddressSame();
		validateCustomer();
		riskDetails();
		
		selfAddInsured();
		secondAddInsured();
		thirdAddInsured();
		nominee();
		
	    //close_Window();

	}

}
